<html> 
<body> 
<?php 

$bdd = new PDO('mysql:host=127.0.0.1;dbname=asterisk', 'root', '');

$insertmbr = $bdd->prepare("DELETE FROM g_users_spe WHERE id=");
$insertmbr->execute(array($nomEntreprise, $AjouterPass, $AjouterDCID, $AjouterPCCID, $AjouterPCM, $AjouterCG, $AjouterBN, $AjouterNTP, $AjouterPP));
header("Location: index.php");

?>
</body>
</html>